# Define the file path
timestamp_file = "F:\\CODE\\pythonscripts\\FINAL\\MASTER_SCRIPT\\Assets\\timestamps_8.txt"

# Initialize arrays for start and end times
start_times = []
end_times = []

# Read and parse the file
with open(timestamp_file, 'r') as file:
    lines = file.readlines()
    email_times = {}  # Dictionary to store email times

    for line in lines:
        print(f"Processing line: {line.strip()}")  # Debug statement
        parts = line.strip().split()
        timestamp = int(parts[0])
        action = parts[2]  # Corrected index for action
        email_id = int(parts[3])  # Corrected index for email ID

        if email_id not in email_times:
            email_times[email_id] = {'start': None, 'end': None}

        if action == 'start':
            email_times[email_id]['start'] = timestamp
        elif action == 'end':
            email_times[email_id]['end'] = timestamp

    # Filter out emails that have both start and end times
    for email_id, times in email_times.items():
        print(f"Email ID: {email_id}, Times: {times}")  # Debug statement
        if times['start'] is not None and times['end'] is not None:
            start_times.append(times['start'])
            end_times.append(times['end'])

# Print the results
print("Start times:", start_times)
print("End times:", end_times)
